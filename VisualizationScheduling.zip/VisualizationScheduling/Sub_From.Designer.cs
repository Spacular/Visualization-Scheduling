﻿namespace VisualizationScheduling
{
    partial class Sub_From
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.ID_FCFS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WatingTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BurstTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priorty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FCFS_panel = new System.Windows.Forms.Panel();
            this.FCFS_label = new System.Windows.Forms.Label();
            this.FCFS_label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FCFC_Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.FCFS_Chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.SJF_Chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.SJF_Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.SJF_label2 = new System.Windows.Forms.Label();
            this.SJF_label = new System.Windows.Forms.Label();
            this.SJF_panel = new System.Windows.Forms.Panel();
            this.SRT_Chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.SRT_Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.ID_SRT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WaitingTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SRT_label2 = new System.Windows.Forms.Label();
            this.SRT_label = new System.Windows.Forms.Label();
            this.SRT_panel = new System.Windows.Forms.Panel();
            this.Priorty_Chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Priorty_Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.ID_Priorty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priorty_label2 = new System.Windows.Forms.Label();
            this.Priorty_label = new System.Windows.Forms.Label();
            this.Priorty_panel = new System.Windows.Forms.Panel();
            this.ID_SJF = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FCFC_Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FCFS_Chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SJF_Chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SJF_Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SRT_Chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SRT_Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Priorty_Chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Priorty_Chart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // ID_FCFS
            // 
            this.ID_FCFS.Name = "ID_FCFS";
            // 
            // WatingTime
            // 
            this.WatingTime.Name = "WatingTime";
            // 
            // BurstTime
            // 
            this.BurstTime.Name = "BurstTime";
            // 
            // Priorty
            // 
            this.Priorty.Name = "Priorty";
            // 
            // FCFS_panel
            // 
            this.FCFS_panel.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.FCFS_panel.AutoScroll = true;
            this.FCFS_panel.AutoScrollMinSize = new System.Drawing.Size(603, 164);
            this.FCFS_panel.BackColor = System.Drawing.Color.White;
            this.FCFS_panel.Location = new System.Drawing.Point(1174, 29);
            this.FCFS_panel.Name = "FCFS_panel";
            this.FCFS_panel.Size = new System.Drawing.Size(603, 164);
            this.FCFS_panel.TabIndex = 0;
            this.FCFS_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // FCFS_label
            // 
            this.FCFS_label.AutoSize = true;
            this.FCFS_label.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FCFS_label.Location = new System.Drawing.Point(1187, 216);
            this.FCFS_label.Name = "FCFS_label";
            this.FCFS_label.Size = new System.Drawing.Size(138, 20);
            this.FCFS_label.TabIndex = 1;
            this.FCFS_label.Text = "출력데이터 : ";
            // 
            // FCFS_label2
            // 
            this.FCFS_label2.AutoSize = true;
            this.FCFS_label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.FCFS_label2.Location = new System.Drawing.Point(1187, 255);
            this.FCFS_label2.Name = "FCFS_label2";
            this.FCFS_label2.Size = new System.Drawing.Size(159, 20);
            this.FCFS_label2.TabIndex = 2;
            this.FCFS_label2.Text = "평균대기시간 : ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_FCFS,
            this.BurstTime,
            this.WatingTime,
            this.Priorty});
            this.dataGridView1.Location = new System.Drawing.Point(13, 30);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(471, 248);
            this.dataGridView1.TabIndex = 4;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1842, 28);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(52, 24);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click_1);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(68, 24);
            this.saveAsToolStripMenuItem.Text = "SaveAs";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click_1);
            // 
            // FCFC_Chart
            // 
            chartArea1.Name = "ChartArea1";
            this.FCFC_Chart.ChartAreas.Add(chartArea1);
            this.FCFC_Chart.Cursor = System.Windows.Forms.Cursors.Cross;
            legend1.Name = "Legend1";
            this.FCFC_Chart.Legends.Add(legend1);
            this.FCFC_Chart.Location = new System.Drawing.Point(484, 30);
            this.FCFC_Chart.Name = "FCFC_Chart";
            this.FCFC_Chart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series1.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Unscaled;
            series1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series1.BorderWidth = 2;
            series1.ChartArea = "ChartArea1";
            series1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            series1.IsValueShownAsLabel = true;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.FCFC_Chart.Series.Add(series1);
            this.FCFC_Chart.Size = new System.Drawing.Size(345, 248);
            this.FCFC_Chart.TabIndex = 8;
            // 
            // FCFS_Chart2
            // 
            chartArea2.Name = "ChartArea1";
            this.FCFS_Chart2.ChartAreas.Add(chartArea2);
            this.FCFS_Chart2.Cursor = System.Windows.Forms.Cursors.Cross;
            legend2.Name = "Legend1";
            this.FCFS_Chart2.Legends.Add(legend2);
            this.FCFS_Chart2.Location = new System.Drawing.Point(829, 30);
            this.FCFS_Chart2.Name = "FCFS_Chart2";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series2.IsValueShownAsLabel = true;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            series2.YValuesPerPoint = 2;
            this.FCFS_Chart2.Series.Add(series2);
            this.FCFS_Chart2.Size = new System.Drawing.Size(345, 248);
            this.FCFS_Chart2.TabIndex = 11;
            this.FCFS_Chart2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FCFS_Chart2_MouseClick);
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // SJF_Chart2
            // 
            chartArea3.Name = "ChartArea1";
            this.SJF_Chart2.ChartAreas.Add(chartArea3);
            this.SJF_Chart2.Cursor = System.Windows.Forms.Cursors.Cross;
            legend3.Name = "Legend1";
            this.SJF_Chart2.Legends.Add(legend3);
            this.SJF_Chart2.Location = new System.Drawing.Point(829, 278);
            this.SJF_Chart2.Name = "SJF_Chart2";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series3.IsValueShownAsLabel = true;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            series3.YValuesPerPoint = 2;
            this.SJF_Chart2.Series.Add(series3);
            this.SJF_Chart2.Size = new System.Drawing.Size(345, 248);
            this.SJF_Chart2.TabIndex = 18;
            // 
            // SJF_Chart
            // 
            chartArea4.Name = "ChartArea1";
            this.SJF_Chart.ChartAreas.Add(chartArea4);
            this.SJF_Chart.Cursor = System.Windows.Forms.Cursors.Cross;
            legend4.Name = "Legend1";
            this.SJF_Chart.Legends.Add(legend4);
            this.SJF_Chart.Location = new System.Drawing.Point(484, 278);
            this.SJF_Chart.Name = "SJF_Chart";
            this.SJF_Chart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series4.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Unscaled;
            series4.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series4.BorderWidth = 2;
            series4.ChartArea = "ChartArea1";
            series4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            series4.IsValueShownAsLabel = true;
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            series4.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.SJF_Chart.Series.Add(series4);
            this.SJF_Chart.Size = new System.Drawing.Size(345, 248);
            this.SJF_Chart.TabIndex = 17;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_SJF,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dataGridView2.Location = new System.Drawing.Point(13, 277);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(471, 248);
            this.dataGridView2.TabIndex = 16;
            // 
            // SJF_label2
            // 
            this.SJF_label2.AutoSize = true;
            this.SJF_label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SJF_label2.Location = new System.Drawing.Point(1187, 509);
            this.SJF_label2.Name = "SJF_label2";
            this.SJF_label2.Size = new System.Drawing.Size(159, 20);
            this.SJF_label2.TabIndex = 15;
            this.SJF_label2.Text = "평균대기시간 : ";
            // 
            // SJF_label
            // 
            this.SJF_label.AutoSize = true;
            this.SJF_label.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SJF_label.Location = new System.Drawing.Point(1187, 470);
            this.SJF_label.Name = "SJF_label";
            this.SJF_label.Size = new System.Drawing.Size(138, 20);
            this.SJF_label.TabIndex = 14;
            this.SJF_label.Text = "출력데이터 : ";
            // 
            // SJF_panel
            // 
            this.SJF_panel.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.SJF_panel.AutoScroll = true;
            this.SJF_panel.AutoScrollMinSize = new System.Drawing.Size(603, 164);
            this.SJF_panel.BackColor = System.Drawing.Color.White;
            this.SJF_panel.Location = new System.Drawing.Point(1174, 285);
            this.SJF_panel.Name = "SJF_panel";
            this.SJF_panel.Size = new System.Drawing.Size(603, 164);
            this.SJF_panel.TabIndex = 13;
            // 
            // SRT_Chart2
            // 
            chartArea5.Name = "ChartArea1";
            this.SRT_Chart2.ChartAreas.Add(chartArea5);
            this.SRT_Chart2.Cursor = System.Windows.Forms.Cursors.Cross;
            legend5.Name = "Legend1";
            this.SRT_Chart2.Legends.Add(legend5);
            this.SRT_Chart2.Location = new System.Drawing.Point(829, 526);
            this.SRT_Chart2.Name = "SRT_Chart2";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series5.IsValueShownAsLabel = true;
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            series5.YValuesPerPoint = 2;
            this.SRT_Chart2.Series.Add(series5);
            this.SRT_Chart2.Size = new System.Drawing.Size(345, 248);
            this.SRT_Chart2.TabIndex = 24;
            // 
            // SRT_Chart
            // 
            chartArea6.Name = "ChartArea1";
            this.SRT_Chart.ChartAreas.Add(chartArea6);
            this.SRT_Chart.Cursor = System.Windows.Forms.Cursors.Cross;
            legend6.Name = "Legend1";
            this.SRT_Chart.Legends.Add(legend6);
            this.SRT_Chart.Location = new System.Drawing.Point(484, 526);
            this.SRT_Chart.Name = "SRT_Chart";
            this.SRT_Chart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series6.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Unscaled;
            series6.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series6.BorderWidth = 2;
            series6.ChartArea = "ChartArea1";
            series6.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            series6.IsValueShownAsLabel = true;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            series6.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.SRT_Chart.Series.Add(series6);
            this.SRT_Chart.Size = new System.Drawing.Size(345, 248);
            this.SRT_Chart.TabIndex = 23;
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_SRT,
            this.dataGridViewTextBoxColumn6,
            this.WaitingTime,
            this.dataGridViewTextBoxColumn8});
            this.dataGridView3.Location = new System.Drawing.Point(13, 524);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(471, 248);
            this.dataGridView3.TabIndex = 22;
            // 
            // ID_SRT
            // 
            this.ID_SRT.Name = "ID_SRT";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // WaitingTime
            // 
            this.WaitingTime.Name = "WaitingTime";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // SRT_label2
            // 
            this.SRT_label2.AutoSize = true;
            this.SRT_label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SRT_label2.Location = new System.Drawing.Point(1187, 763);
            this.SRT_label2.Name = "SRT_label2";
            this.SRT_label2.Size = new System.Drawing.Size(159, 20);
            this.SRT_label2.TabIndex = 21;
            this.SRT_label2.Text = "평균대기시간 : ";
            // 
            // SRT_label
            // 
            this.SRT_label.AutoSize = true;
            this.SRT_label.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.SRT_label.Location = new System.Drawing.Point(1187, 724);
            this.SRT_label.Name = "SRT_label";
            this.SRT_label.Size = new System.Drawing.Size(138, 20);
            this.SRT_label.TabIndex = 20;
            this.SRT_label.Text = "출력데이터 : ";
            // 
            // SRT_panel
            // 
            this.SRT_panel.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.SRT_panel.AutoScroll = true;
            this.SRT_panel.AutoScrollMinSize = new System.Drawing.Size(603, 164);
            this.SRT_panel.BackColor = System.Drawing.Color.White;
            this.SRT_panel.Location = new System.Drawing.Point(1174, 539);
            this.SRT_panel.Name = "SRT_panel";
            this.SRT_panel.Size = new System.Drawing.Size(603, 164);
            this.SRT_panel.TabIndex = 19;
            // 
            // Priorty_Chart2
            // 
            chartArea7.Name = "ChartArea1";
            this.Priorty_Chart2.ChartAreas.Add(chartArea7);
            this.Priorty_Chart2.Cursor = System.Windows.Forms.Cursors.Cross;
            legend7.Name = "Legend1";
            this.Priorty_Chart2.Legends.Add(legend7);
            this.Priorty_Chart2.Location = new System.Drawing.Point(829, 774);
            this.Priorty_Chart2.Name = "Priorty_Chart2";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series7.IsValueShownAsLabel = true;
            series7.Legend = "Legend1";
            series7.Name = "Series1";
            series7.YValuesPerPoint = 2;
            this.Priorty_Chart2.Series.Add(series7);
            this.Priorty_Chart2.Size = new System.Drawing.Size(345, 248);
            this.Priorty_Chart2.TabIndex = 30;
            // 
            // Priorty_Chart
            // 
            chartArea8.Name = "ChartArea1";
            this.Priorty_Chart.ChartAreas.Add(chartArea8);
            this.Priorty_Chart.Cursor = System.Windows.Forms.Cursors.Cross;
            legend8.Name = "Legend1";
            this.Priorty_Chart.Legends.Add(legend8);
            this.Priorty_Chart.Location = new System.Drawing.Point(484, 774);
            this.Priorty_Chart.Name = "Priorty_Chart";
            this.Priorty_Chart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series8.BackImageWrapMode = System.Windows.Forms.DataVisualization.Charting.ChartImageWrapMode.Unscaled;
            series8.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            series8.BorderWidth = 2;
            series8.ChartArea = "ChartArea1";
            series8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            series8.IsValueShownAsLabel = true;
            series8.Legend = "Legend1";
            series8.Name = "Series1";
            series8.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            this.Priorty_Chart.Series.Add(series8);
            this.Priorty_Chart.Size = new System.Drawing.Size(345, 248);
            this.Priorty_Chart.TabIndex = 29;
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_Priorty,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dataGridView4.Location = new System.Drawing.Point(13, 771);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(471, 248);
            this.dataGridView4.TabIndex = 28;
            // 
            // ID_Priorty
            // 
            this.ID_Priorty.Name = "ID_Priorty";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // Priorty_label2
            // 
            this.Priorty_label2.AutoSize = true;
            this.Priorty_label2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Priorty_label2.Location = new System.Drawing.Point(1187, 1014);
            this.Priorty_label2.Name = "Priorty_label2";
            this.Priorty_label2.Size = new System.Drawing.Size(159, 20);
            this.Priorty_label2.TabIndex = 27;
            this.Priorty_label2.Text = "평균대기시간 : ";
            // 
            // Priorty_label
            // 
            this.Priorty_label.AutoSize = true;
            this.Priorty_label.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Priorty_label.Location = new System.Drawing.Point(1187, 975);
            this.Priorty_label.Name = "Priorty_label";
            this.Priorty_label.Size = new System.Drawing.Size(138, 20);
            this.Priorty_label.TabIndex = 26;
            this.Priorty_label.Text = "출력데이터 : ";
            // 
            // Priorty_panel
            // 
            this.Priorty_panel.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.Priorty_panel.AutoScroll = true;
            this.Priorty_panel.AutoScrollMinSize = new System.Drawing.Size(603, 164);
            this.Priorty_panel.BackColor = System.Drawing.Color.White;
            this.Priorty_panel.Location = new System.Drawing.Point(1174, 790);
            this.Priorty_panel.Name = "Priorty_panel";
            this.Priorty_panel.Size = new System.Drawing.Size(603, 164);
            this.Priorty_panel.TabIndex = 25;
            // 
            // ID_SJF
            // 
            this.ID_SJF.HeaderText = "ID_SJF";
            this.ID_SJF.Name = "ID_SJF";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "BurstTime";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Sub_From
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1842, 1045);
            this.Controls.Add(this.Priorty_Chart2);
            this.Controls.Add(this.Priorty_Chart);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.Priorty_label2);
            this.Controls.Add(this.Priorty_label);
            this.Controls.Add(this.Priorty_panel);
            this.Controls.Add(this.SRT_Chart2);
            this.Controls.Add(this.SRT_Chart);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.SRT_label2);
            this.Controls.Add(this.SRT_label);
            this.Controls.Add(this.SRT_panel);
            this.Controls.Add(this.SJF_Chart2);
            this.Controls.Add(this.SJF_Chart);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.SJF_label2);
            this.Controls.Add(this.SJF_label);
            this.Controls.Add(this.SJF_panel);
            this.Controls.Add(this.FCFS_Chart2);
            this.Controls.Add(this.FCFC_Chart);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.FCFS_label2);
            this.Controls.Add(this.FCFS_label);
            this.Controls.Add(this.FCFS_panel);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Sub_From";
            this.Text = "Sub_From";
            this.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.FCFS_MouseWheel);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.FCFC_Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FCFS_Chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SJF_Chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SJF_Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SRT_Chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SRT_Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Priorty_Chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Priorty_Chart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel FCFS_panel;
        private System.Windows.Forms.Label FCFS_label;
        private System.Windows.Forms.Label FCFS_label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProcessID;
        private System.Windows.Forms.DataGridViewTextBoxColumn WatingTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn BurstTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priorty;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.DataVisualization.Charting.Chart FCFC_Chart;
        private System.Windows.Forms.DataVisualization.Charting.Chart FCFS_Chart2;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProcessID_FCFS;
        private System.Windows.Forms.DataGridViewTextBoxColumn WatingTime_FCFS;
        private System.Windows.Forms.DataGridViewTextBoxColumn BurstTime_FCFS;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priorty_FCFS;
        private System.Windows.Forms.DataVisualization.Charting.Chart SJF_Chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart SJF_Chart;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label SJF_label2;
        private System.Windows.Forms.Label SJF_label;
        private System.Windows.Forms.Panel SJF_panel;
        private System.Windows.Forms.DataVisualization.Charting.Chart SRT_Chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart SRT_Chart;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Label SRT_label2;
        private System.Windows.Forms.Label SRT_label;
        private System.Windows.Forms.Panel SRT_panel;
        private System.Windows.Forms.DataVisualization.Charting.Chart Priorty_Chart2;
        private System.Windows.Forms.DataVisualization.Charting.Chart Priorty_Chart;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Label Priorty_label2;
        private System.Windows.Forms.Label Priorty_label;
        private System.Windows.Forms.Panel Priorty_panel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_FCFS;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SRT;
        private System.Windows.Forms.DataGridViewTextBoxColumn WaitingTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Priorty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SJF;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;


    }
}